<div id="to-top">
    <a href="#page-header">
        <span class="icon-circle-up"></span>
    </a>
</div>