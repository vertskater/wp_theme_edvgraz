<?php get_header();?>
<main  id="content" class="error">
    <section class="container">
        <div class="button-edvgraz">
            <a href="<?php echo get_home_url();?>" class="btn">
                <span class="btn-header-icon btn-classic icon-home"></span>
                <span class="btn-header-text btn-classic"><?php _e('zurück zur Startseite', 'edvgraz');?></span>
            </a>
        </div>
    </section>
</main>
<?php get_footer();?>